#!/bin/bash 
while true; do
    if pgrep -x firefox >/dev/null; then
        # Firefox  ^ ang ch   y -> kh  ng l  m g  
        sleep 1
    else
        while true; do
            rm -rf /home/*/.cache /home/*/.mozilla
            sleep 1
        done
    fi
done 
