#!/bin/sh
# Keep Labtainer .lab submissions small without deleting grading artifacts.
# Important: instr_config/pregrade.sh extracts Firefox history from
# /home/<user>/.mozilla/firefox/*default/places.sqlite, so do NOT remove
# the whole .mozilla directory.

set -eu

# Give systemd/user-session startup a moment to finish.
sleep 10

# One-time cleanup for stale ZAP data under /home. The Dockerfile patch below
# redirects new ZAP sessions to /tmp/${USER}/.ZAP, so this should not affect new use.
find /home -mindepth 2 -maxdepth 2 -type d -name ".ZAP" \
  -prune -exec rm -rf {} + 2>/dev/null || true

while true; do
  # Remove browser/cache directories that can grow large but keep Firefox profile
  # metadata such as places.sqlite for Labtainer pregrade/checkwork.
  find /home -type d \( \
      -path "*/.cache" -o \
      -path "*/.mozilla/firefox/*/cache2" -o \
      -path "*/.mozilla/firefox/*/startupCache" -o \
      -path "*/.mozilla/firefox/*/thumbnails" \
    \) -prune -exec rm -rf {} + 2>/dev/null || true

  sleep 30
done
