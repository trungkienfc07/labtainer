#!/bin/sh
# Patch the OWASP ZAP launcher so its session directory lives outside /home.
# This follows the optimization guidance while avoiding wholesale replacement
# of the ZAP launcher bundled in the base image.

set -eu

zap_cmd="$(command -v owasp-zap 2>/dev/null || command -v zaproxy 2>/dev/null || true)"
if [ -z "$zap_cmd" ]; then
  echo "[labtainer] OWASP ZAP launcher not found; skipping ZAP_HOME patch" >&2
  exit 0
fi

launcher="$(readlink -f "$zap_cmd")"
if [ ! -f "$launcher" ]; then
  echo "[labtainer] OWASP ZAP launcher path is not a regular file: $launcher" >&2
  exit 0
fi

if grep -q "LABTAINER_ZAP_HOME_PATCH" "$launcher"; then
  echo "[labtainer] ZAP launcher already patched: $launcher" >&2
  exit 0
fi

cp "$launcher" "${launcher}.labtainer.bak"
tmp="$(mktemp)"

# Most ZAP launchers used in Labtainer define ARGS=("$@"). Inject -dir there,
# keeping all original JVM/JAR logic intact.
if awk '
  BEGIN { patched = 0 }
  {
    print
    if (!patched && $0 ~ /^ARGS=\("\$@"\)/) {
      print ""
      print "# LABTAINER_ZAP_HOME_PATCH: keep large ZAP session files outside /home"
      print "ZAP_HOME=\"${ZAP_HOME:-/tmp/${USER:-ubuntu}/.ZAP}\""
      print "mkdir -p \"$ZAP_HOME\" 2>/dev/null || true"
      print "ARGS=(\"-dir\" \"$ZAP_HOME\" \"${ARGS[@]}\")"
      patched = 1
    }
  }
  END { if (!patched) exit 42 }
' "$launcher" > "$tmp"; then
  cat "$tmp" > "$launcher"
  chmod 755 "$launcher"
  rm -f "$tmp"
  echo "[labtainer] Patched ZAP launcher: $launcher" >&2
  exit 0
else
  rm -f "$tmp"
  echo "[labtainer] Could not auto-patch $launcher; restore point is ${launcher}.labtainer.bak" >&2
  echo "[labtainer] Expected an ARGS=(\"\$@\") line. Patch launcher manually if needed." >&2
  # Do not fail the whole image build; the cache-cleaner still reduces .lab size.
  exit 0
fi
