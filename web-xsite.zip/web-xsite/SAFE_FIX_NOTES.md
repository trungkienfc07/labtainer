# web-xsite safe fix

This package keeps the original vuln-site web files intact.
Only the Apache virtual host name/aliases were corrected so the browser URL `www.xsslabelgg.com` maps to the Elgg DocumentRoot instead of the CentOS Apache default page.

No Elgg runtime directories are removed in this safe package.
