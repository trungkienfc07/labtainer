# ptit-backup3 Labtainer layout

This archive includes the missing Labtainer container directories, matching the container names in `config/start.config`:

- `source/`
- `destination/`

It also includes Dockerfiles named in the Labtainer convention:

- `dockerfiles/Dockerfile.ptit-backup3.source.student`
- `dockerfiles/Dockerfile.ptit-backup3.destination.student`

The `source` container has sample files for tasks 1 and 2:

- `/home/ubuntu/backupme`
- `/home/ubuntu/backupthisdir/file1.txt`
- `/home/ubuntu/backupthisdir/file2.txt`
- `/home/ubuntu/backupthisdir/file3.txt`

The `destination` container starts SSH and accepts password login for:

- user: `ubuntu`
- password: `attt@123`

Expected commands from the `source` terminal:

```bash
rsync -zvh backupme /tmp/backup/
rsync -zavh backupthisdir/ /tmp/backup/backupthisdir/
rsync -avzhe ssh backupme ubuntu@192.168.1.3:/tmp/backup/
```

Note: the original `results.config` checks task 2 at `source:/etc/result/result2`, which does not match the lab manual text that says `/tmp/backup`. That grading rule should be fixed separately if you want task 2 to grade the actual backed-up folder.
